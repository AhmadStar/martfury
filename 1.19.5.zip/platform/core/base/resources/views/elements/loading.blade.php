<div class="half-circle-spinner loading-spinner">
    <div class="circle circle-1"></div>
    <div class="circle circle-2"></div>
</div>
