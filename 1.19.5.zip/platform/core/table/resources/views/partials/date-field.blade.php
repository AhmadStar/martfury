<div class="input-group">
    {!! $content !!}
    <span class="input-group-text">
        <span class="input-group-text"><i class="fa fa-calendar"></i></span>
    </span>
</div>
